import { ProfileStore, ServiceError } from './profile-store.mjs';
import { consentRecord } from './pilot-policy.mjs';

// Same-origin transport. The HttpOnly session and JWT stay on the server side.
export class NeonStore extends ProfileStore {
  mode = 'neon';
  #user = null;
  #restoreRevision = 0;
  constructor(config, fetchImpl = fetch) {
    super();
    if (config.backend !== 'neon') throw new Error('Потрібна конфігурація Neon');
    this.fetch = (...args) => fetchImpl(...args);
    this.pilotSafetyEnabled = config.pilotSafetyEnabled === true;
    this.realPilotEnabled = config.realPilotEnabled === true;
    this.googleOAuthEnabled = config.googleOAuthEnabled === true;
    this.liveLocationEnabled = config.liveLocationEnabled === true;
    this.meetingAddressEnabled = config.meetingAddressEnabled === true;
    this.profileErasureEnabled = config.profileErasureEnabled === true;
    this.completeErasureEnabled = this.profileErasureEnabled && config.completeErasureEnabled === true;
    this.caseExportEnabled = config.realJourneyEnabled === true;
    this.googleOAuthInitUrl = config.googleOAuthInitUrl || '';
    this.publicSiteUrl = config.publicSiteUrl || '';
  }
  get user() { return this.#user; }
  // This route uses a browser-session cookie; it never persists a JS-readable token.
  remember() {}
  forgetStoredSession() {}
  async #request(path, { method = 'GET', body, prefer } = {}) {
    const actor = this.#user;
    const response = await this.fetch(path, { method, credentials: 'same-origin', cache: 'no-store',
      headers: { 'Content-Type': 'application/json', 'X-Synera-Client': '1', ...(prefer ? { Prefer: prefer } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(20000) });
    if (!response.ok) {
      if (response.status === 401 && this.#user === actor) this.#user = null;
      const details = await response.json().catch(() => null);
      throw new ServiceError(response.status, details?.error);
    }
    const text = await response.text();
    return text ? JSON.parse(text) : null;
  }
  async availability() { return this.#request('/api/neon/health'); }
  async eraseProfileData() {
    return this.#eraseData(false);
  }
  async eraseCompleteApplicationData(confirmation) {
    if (!this.completeErasureEnabled) throw new ServiceError(503, 'profile_erasure_not_ready');
    if (confirmation !== 'DELETE ALL') throw new ServiceError(400, 'profile_erasure_confirmation_required');
    return this.#eraseData(true);
  }
  async #eraseData(complete) {
    this.requireUser();
    if (!this.profileErasureEnabled) throw new ServiceError(503, 'profile_erasure_not_ready');
    const actor = this.#user;
    let result;
    try {
      result = await this.#request(complete ? '/api/neon/privacy-erasure' : '/api/neon/profile-erasure', {method:'POST',body:{confirm:complete ? 'ERASE_ALL_APPLICATION_DATA' : 'ERASE_APPLICATION_DATA',expectedSubject:actor.id}});
    } catch (error) {
      // Drop the stale displayed account, but never overwrite a newer local login.
      if (error.code === 'profile_erasure_subject_mismatch' && this.#user === actor) this.#user = null;
      throw error;
    }
    if (this.#user !== actor) throw Object.assign(new ServiceError(409), {
      code:'profile_erasure_session_changed', message:'Сесія змінилася. Результат попереднього запиту не змінює поточний акаунт.',
    });
    if (result?.status !== (complete ? 'application_data_completely_erased' : 'application_data_erased') || result.providerDeletion !== 'pending' ||
        (complete ? result.staleSessionTombstone !== 'retained' : result.retainedScope !== 'bilateral_records_and_safety_evidence') || typeof result.repeated !== 'boolean' ||
        typeof result.sessionRevoked !== 'boolean') throw new ServiceError(503, 'profile_erasure_unconfirmed');
    this.#user = null;
    return result;
  }
  async _caseOutcome(caseId, payload) {
    this.requireUser();
    if (typeof caseId !== 'string' || !/^[A-Za-z0-9_:-]{1,64}$/.test(caseId)) throw new ServiceError(400);
    return this.#request('/api/neon/outcomes/' + caseId, { method: 'POST', body: payload });
  }
  async _meetingAddress(meetingId, caseId, payload) {
    this.requireUser();
    if (typeof meetingId !== 'string' || !/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(meetingId) ||
        typeof caseId !== 'string' || !/^[A-Za-z0-9_:-]{1,64}$/.test(caseId)) throw new ServiceError(400);
    return this.#request('/api/neon/meeting-address/' + meetingId + '/' + caseId, { method: 'POST', body: payload });
  }
  async _messageIntent(meetingId, intentId, text) {
    this.requireRealPilot();
    return this.#request('/api/neon/messages/' + meetingId, { method: 'POST', body: { intentId, text } });
  }
  async #location(id, action, body = {}) {
    this.requireUser();
    if (!this.liveLocationEnabled || typeof id !== 'string' || !/^[0-9a-f-]{36}$/i.test(id)) throw new ServiceError(400);
    return this.#request('/api/neon/location/' + id + '/' + action, { method: 'POST', body });
  }
  locationState(id) { return this.#location(id, 'view'); }
  grantLocation(id, options) { return this.#location(id, 'grant', options); }
  publishLocation(id, sample) { return this.#location(id, 'sample', sample); }
  revokeLocation(id) { return this.#location(id, 'revoke'); }
  async setMeetingAddress(id, address) {
    this.requireUser();
    if (this.meetingAddressEnabled) throw new ServiceError(409);
    if (!this.liveLocationEnabled || typeof address !== 'string' || address.length > 200) throw new ServiceError(400);
    const rows = await this._send('/rest/v1/meeting_requests?id=eq.' + encodeURIComponent(id) + '&status=eq.accepted', {
      method: 'PATCH', prefer: 'return=representation', body: { meeting_address: address.trim() },
    });
    if (rows.length !== 1) throw new ServiceError(403);
  }
  async restore() {
    const actor = this.#user, revision = ++this.#restoreRevision;
    const data = await this.#request('/api/neon/session');
    if (this.#user !== actor || revision !== this.#restoreRevision) return Boolean(this.#user);
    this.#user = data?.user || null;
    return Boolean(this.#user);
  }
  async requestOtp(email, accepted) {
    if (!this.pilotSafetyEnabled || !this.realPilotEnabled) throw new ServiceError(503);
    const consent = consentRecord(accepted);
    return this.#request('/api/neon/otp/request', { method: 'POST', body: { email, consent } });
  }
  async verifyOtp(email, otp) {
    if (!/^\d{6}$/.test(otp)) throw new ServiceError(400);
    const data = await this.#request('/api/neon/otp/verify', { method: 'POST', body: { email, otp } });
    this.#user = data?.user || null;
    if (!this.#user?.id) throw new ServiceError(401);
  }
  async beginGoogleSignIn(accepted) {
    if (!this.googleOAuthEnabled || !this.pilotSafetyEnabled || !this.realPilotEnabled) throw new ServiceError(503);
    const consent = consentRecord(accepted);
    const data = await this.#request('/api/neon/oauth/google/start', { method: 'POST', body: { consent } });
    let destination, expected;
    try { destination = new URL(data?.url); expected = new URL(this.googleOAuthInitUrl); } catch { throw new ServiceError(503); }
    const token = destination.searchParams.getAll('token');
    if (expected.protocol !== 'https:' || expected.username || expected.password || expected.search || expected.hash ||
        destination.protocol !== 'https:' || destination.origin !== expected.origin || destination.pathname !== expected.pathname || destination.port ||
        destination.username || destination.password || destination.hash || token.length !== 1 || !/^[A-Za-z0-9._~-]{16,2048}$/.test(token[0]) ||
        [...destination.searchParams.keys()].some(key => key !== 'token')) throw new ServiceError(503);
    window.location.assign(destination.href);
  }
  async signOut() {
    try { await this.#request('/api/neon/logout', { method: 'POST', body: {} }); }
    finally { this.#user = null; }
  }
  async _send(path, options = {}) {
    this.requireUser();
    if (!path.startsWith('/rest/v1/')) throw new Error('Непідтримуваний запит даних Neon');
    return this.#request('/api/neon/data/' + path.slice('/rest/v1/'.length), options);
  }
}
