export const POLICY_VERSION = '2026-09-05-pilot-3';
export const OPERATOR = Object.freeze({ name: 'Andrii Pokrovskyi', email: 'andriipokrovskyi@gmail.com' });
export function consentRecord(value = {}) {
  const terms = value.terms === true || value.terms_accepted === true;
  const privacy = value.privacy === true || value.privacy_acknowledged === true;
  const demo = value.demo === true;
  if (terms !== true || privacy !== true) throw new Error('Прочитай правила й повідомлення про дані та підтвердь обидва пункти.');
  return { policy_version: POLICY_VERSION, terms_accepted: true, privacy_acknowledged: true, demo_only: demo === true };
}
export const GPT_PROFILE_PROMPT = `Допоможи мені перенести ВЛАСНИЙ професійний профіль у Synera. Використай лише те, що я явно повідомив у цій розмові. Не вигадуй факти, посади, вміння чи результати. Не додавай email, телефон, точну адресу, ключі, здоров'я, фінансові реквізити, приватні дані інших людей або текст усієї переписки. Якщо чогось не знаєш, залиш порожній рядок. Стисло опиши конкретну користь, яку я можу дати, і що шукаю. Поверни тільки JSON без markdown:
{"format":"synera-profile-1","profile":{"display_name":"до 60 символів","city":"місто, до 80 символів","offers":"конкретно, до 300 символів","seeks":"конкретно, до 300 символів","is_discoverable":false}}
Я сам перевірю прев'ю в Synera перед збереженням.`;

const handleGoogleOAuth = (() => {


const START_PATH = '/api/neon/oauth/google/start';
const CALLBACK_PATH = '/api/neon/oauth/google/callback';
const VERIFIER = 'neon_auth_session_verifier';
const CANONICAL_CHALLENGE = '__Secure-neon-auth.session_challenge';
const LEGACY_CHALLENGE = '__Secure-neon-auth.session_challange';
const SESSION_TOKEN = '__Secure-neon-auth.session_token';
const LOCAL_CHALLENGES = new Map([
  [CANONICAL_CHALLENGE, '__Host-synera-google-challenge'],
  [LEGACY_CHALLENGE, '__Host-synera-google-challange'],
]);
const jsonHeaders = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' };
const answer = (data, status, headers = {}, cookies = []) => {
  const responseHeaders = new Headers({ ...jsonHeaders, ...headers });
  for (const cookie of cookies) responseHeaders.append('Set-Cookie', cookie);
  return new Response(JSON.stringify(data), { status, headers: responseHeaders });
};
class OAuthError extends Error { constructor(status, code = 'google_oauth_unavailable') { super('Google OAuth rejected'); this.status = status; this.code = code; } }

function clearChallenges() {
  return [...LOCAL_CHALLENGES.values()].map(name => `${name}=; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=0`);
}
function localChallenge(name, value, maxAge) {
  const encoded = btoa(JSON.stringify({ name, value })).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
  if (encoded.length > 3800) throw new OAuthError(503);
  return `${LOCAL_CHALLENGES.get(name)}=${encoded}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
}
function parseCookieValues(request, name) {
  return (request.headers.get('cookie') || '').split(';').map(value => value.trim()).filter(value => value.startsWith(name + '=')).map(value => value.slice(name.length + 1));
}
function decodeLocalChallenge(request) {
  const matches = [...LOCAL_CHALLENGES.values()].flatMap(name => parseCookieValues(request, name).map(value => ({ name, value })));
  if (matches.length !== 1 || matches[0].value.length > 3800) throw new OAuthError(400, 'google_oauth_invalid_callback');
  try {
    const base64 = matches[0].value.replaceAll('-', '+').replaceAll('_', '/') + '='.repeat((4 - matches[0].value.length % 4) % 4);
    const data = JSON.parse(atob(base64));
    if (LOCAL_CHALLENGES.get(data?.name) !== matches[0].name || typeof data?.value !== 'string' || !/^[^\x00-\x20;]{1,2048}$/.test(data.value)) throw new Error();
    return data;
  } catch { throw new OAuthError(400, 'google_oauth_invalid_callback'); }
}
function setCookies(response) {
  const values = response.headers.getSetCookie?.() || [];
  if (!Array.isArray(values)) throw new OAuthError(503);
  return values;
}
function parseSetCookie(value) {
  const [first, ...attributes] = value.split(';').map(part => part.trim());
  const match = /^([^=]+)=([^\s;]+)$/.exec(first || '');
  if (!match) return null;
  const fields = new Map(attributes.map(attribute => {
    const index = attribute.indexOf('=');
    return [index < 0 ? attribute.toLowerCase() : attribute.slice(0, index).toLowerCase(), index < 0 ? true : attribute.slice(index + 1)];
  }));
  return { name: match[1], value: match[2], fields };
}
function upstreamChallenge(response) {
  const parsed = setCookies(response).map(parseSetCookie);
  if (parsed.length !== 1 || !parsed[0] || !LOCAL_CHALLENGES.has(parsed[0].name)) throw new OAuthError(503);
  const cookie = parsed[0], maxAge = Number(cookie.fields.get('max-age'));
  if (!Number.isInteger(maxAge) || maxAge < 1 || maxAge > 600 || cookie.fields.get('secure') !== true || cookie.fields.get('httponly') !== true || !/^[^\x00-\x20;]{1,2048}$/.test(cookie.value)) throw new OAuthError(503);
  return { name: cookie.name, value: cookie.value, maxAge };
}
function upstreamSession(response) {
  const parsed = setCookies(response).map(parseSetCookie).filter(cookie => cookie?.name === SESSION_TOKEN);
  if (parsed.length !== 1 || !/^[^\x00-\x20;]{1,4096}$/.test(parsed[0].value)) throw new OAuthError(503);
  return parsed[0].value;
}
function publicUser(data, allowed, env) {
  const user = data?.user;
  const admitted = typeof user?.email === 'string' && (env.SYNERA_OPEN_REGISTRATION === 'true'
    ? user.email.length <= 254 && /^[^\s@,]+@[^\s@,]+\.[^\s@,]+$/.test(user.email)
    : allowed?.has(user.email.toLowerCase()));
  if (!data?.session || !user || typeof user.id !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(user.id) || typeof user.email !== 'string' || user.emailVerified !== true || !admitted) throw new OAuthError(401, 'google_oauth_denied');
  return { id: user.id, email: user.email };
}
function safeNeonInitUrl(value, endpoints) {
  let url;
  try { url = new URL(value); } catch { throw new OAuthError(503); }
  const expected = new URL(endpoints.auth + '/sign-in/social/init');
  const token = url.searchParams.getAll('token');
  if (url.protocol !== 'https:' || url.origin !== expected.origin || url.pathname !== expected.pathname || url.username || url.password || url.hash ||
    token.length !== 1 || !/^[A-Za-z0-9._~-]{16,2048}$/.test(token[0]) || [...url.searchParams.keys()].some(key => key !== 'token')) throw new OAuthError(503);
  return url.href;
}
function enabled(env) { return env.SYNERA_PILOT_READY === 'true' && env.SYNERA_REGISTRATION_ENABLED === 'true' && env.SYNERA_GOOGLE_OAUTH_READY === 'true'; }
async function readConsent(request) {
  if (!/^application\/json(?:;|$)/i.test(request.headers.get('content-type') || '')) throw new OAuthError(415, 'google_oauth_invalid_request');
  if (Number(request.headers.get('content-length')) > 4096) throw new OAuthError(413, 'google_oauth_invalid_request');
  if (!request.body) throw new OAuthError(400, 'google_oauth_invalid_request');
  const reader = request.body.getReader(), chunks = []; let size = 0;
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > 4096) { await reader.cancel(); throw new OAuthError(413, 'google_oauth_invalid_request'); }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  let body;
  try { body = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); } catch { throw new OAuthError(400, 'google_oauth_invalid_request'); }
  if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).length !== 1 || !Object.hasOwn(body, 'consent') || body.consent?.policy_version !== POLICY_VERSION) throw new OAuthError(400, 'google_oauth_invalid_consent');
  try { consentRecord(body.consent); } catch { throw new OAuthError(400, 'google_oauth_invalid_consent'); }
}
async function upstream(fetchImpl, url, init) {
  try {
    const response = await fetchImpl(url, { ...init, redirect: 'manual', cache: 'no-store', signal: AbortSignal.timeout(12000) });
    if (!response.ok) throw new OAuthError(response.status === 401 || response.status === 403 ? 401 : 503);
    return response;
  } catch (error) { if (error instanceof OAuthError) throw error; throw new OAuthError(503); }
}
async function start(request, env, endpoints, fetchImpl) {
  if (!enabled(env)) throw new OAuthError(404, 'not_found');
  await readConsent(request);
  const response = await upstream(fetchImpl, endpoints.auth + '/sign-in/social', { method: 'POST', headers: {
    'Content-Type': 'application/json', Origin: endpoints.origin, 'X-Neon-Auth-Middleware': 'true'
  }, body: JSON.stringify({ provider: 'google', callbackURL: endpoints.origin + CALLBACK_PATH, errorCallbackURL: endpoints.origin + '/', disableRedirect: true }) });
  const challenge = upstreamChallenge(response);
  let data;
  try { data = await response.json(); } catch { throw new OAuthError(503); }
  return answer({ url: safeNeonInitUrl(data?.url, endpoints) }, 200, { 'Set-Cookie': localChallenge(challenge.name, challenge.value, challenge.maxAge) });
}
async function callback(request, env, endpoints, allowed, fetchImpl) {
  if (!enabled(env)) throw new OAuthError(403, 'google_oauth_disabled');
  const url = new URL(request.url), values = url.searchParams.getAll(VERIFIER);
  if (values.length !== 1 || !/^[A-Za-z0-9._~-]{16,1024}$/.test(values[0]) || [...url.searchParams.keys()].some(key => key !== VERIFIER)) throw new OAuthError(400, 'google_oauth_invalid_callback');
  const challenge = decodeLocalChallenge(request);
  const exchangeUrl = new URL(endpoints.auth + '/get-session');
  exchangeUrl.searchParams.set(VERIFIER, values[0]);
  const response = await upstream(fetchImpl, exchangeUrl.href, { method: 'GET', headers: {
    Origin: endpoints.origin, Cookie: `${challenge.name}=${challenge.value}`, 'X-Neon-Auth-Middleware': 'true'
  } });
  let data;
  try { data = await response.json(); } catch { throw new OAuthError(503); }
  publicUser(data, allowed, env);
  const session = upstreamSession(response);
  const headers = new Headers({ Location: endpoints.origin + '/', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
  headers.append('Set-Cookie', `__Host-synera-session=${session}; Path=/; Secure; HttpOnly; SameSite=Lax`);
  for (const cookie of clearChallenges()) headers.append('Set-Cookie', cookie);
  return new Response(null, { status: 303, headers });
}

async function handleGoogleOAuth(request, env, endpoints, allowed, fetchImpl = fetch) {
  const path = new URL(request.url).pathname;
  try {
    if (path === START_PATH && request.method === 'POST') return await start(request, env, endpoints, fetchImpl);
    if (path === CALLBACK_PATH && request.method === 'GET') return await callback(request, env, endpoints, allowed, fetchImpl);
    throw new OAuthError(404, 'not_found');
  } catch (error) {
    const status = error instanceof OAuthError ? error.status : 503;
    const code = error instanceof OAuthError ? error.code : 'google_oauth_unavailable';
    return answer({ error: code, status }, status, {}, clearChallenges());
  }
}

return handleGoogleOAuth;
})();

const { handleMeetingLocation, locationReady } = (() => {
// GEO-01 — meeting-bound live location grant. Pure contract: no browser API, no network, no storage.
// Each participant decides alone (no forced reciprocity); a grant names exactly one recipient, has a
// visible window and precision, keeps only the latest sample and is closed by revocation, cancellation
// or expiry. Live GPS capture stays off in this release: Permissions-Policy geolocation=() is unchanged.
const LOCATION_SCHEMA = 'synera.location-grant.v1';
const LOCATION_PRECISIONS = Object.freeze({ approximate: 500, exact: 50 });
const LOCATION_LEAD_MINUTES = Object.freeze([15, 30]);
const STALE_AFTER_SECONDS = 120;
const ONLINE_PLACES = new Set(['онлайн', 'online']);
const validInstant = value => typeof value === 'string' && Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value;
const validId = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(value);
const isOnline = place => ONLINE_PLACES.has(String(place ?? '').trim().toLocaleLowerCase());
const addMinutes = (iso, minutes) => new Date(Date.parse(iso) + minutes * 60000).toISOString();

function locationEligibility(meeting) {
  if (!meeting || meeting.status !== 'accepted') return { eligible: false, reason: 'MEETING_NOT_ACCEPTED' };
  if (!meeting.proposed_at || !Number.isFinite(Date.parse(meeting.proposed_at))) return { eligible: false, reason: 'MEETING_TIME_MISSING' };
  if (!meeting.meeting_place || isOnline(meeting.meeting_place)) return { eligible: false, reason: 'ONLINE_MEETING' };
  return { eligible: true, reason: null };
}

function createLocationGrant({ meeting, grantorId, precision, leadMinutes, consent, now }) {
  const eligibility = locationEligibility(meeting);
  if (!eligibility.eligible) throw new Error('Місце не можна показувати: ' + eligibility.reason);
  if (consent !== true) throw new Error('Потрібна власна явна згода цієї сторони');
  const participants = [meeting.sender_id, meeting.recipient_id];
  if (!validId(grantorId) || !participants.includes(grantorId) || participants[0] === participants[1]) throw new Error('Дозвіл може дати лише учасник цієї зустрічі');
  if (!Object.hasOwn(LOCATION_PRECISIONS, precision) || !LOCATION_LEAD_MINUTES.includes(leadMinutes) || !validInstant(now)) throw new Error('Некоректна точність, вікно або час');
  const startsAt = new Date(Date.parse(meeting.proposed_at)).toISOString();
  const closesAt = addMinutes(startsAt, Number.isFinite(meeting.duration_minutes) && meeting.duration_minutes > 0 ? Math.min(meeting.duration_minutes, 240) : 60);
  if (now >= closesAt) throw new Error('Зустріч уже завершилась');
  return Object.freeze({
    schema: LOCATION_SCHEMA, meeting_id: meeting.id, grantor_id: grantorId,
    recipient_id: participants.find(id => id !== grantorId),
    precision, radius_m: LOCATION_PRECISIONS[precision], lead_minutes: leadMinutes,
    opens_at: addMinutes(startsAt, -leadMinutes), closes_at: closesAt, granted_at: now,
    status: 'active', sample: null,
  });
}

// Coarsens the position to the chosen precision before it is kept: approximate ≈ 0.005° grid.
function coarsen(value, precision) {
  const step = precision === 'approximate' ? 0.005 : 0.0005;
  return Math.round(value / step) * step;
}

function recordLocationSample(grant, { partyId, lat, lon, accuracyM, at }) {
  if (grant?.schema !== LOCATION_SCHEMA) throw new Error('Некоректний дозвіл');
  if (partyId !== grant.grantor_id) throw new Error('Позицію надсилає лише сторона, що дала дозвіл');
  if (grant.status !== 'active') throw new Error('Дозвіл закрито');
  if (!validInstant(at) || at < grant.opens_at || at >= grant.closes_at) throw new Error('Поза вікном дозволу');
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) throw new Error('Некоректні координати');
  const accuracy = Number.isFinite(accuracyM) && accuracyM > 0 ? Math.round(accuracyM) : null;
  // Minimization: only the latest coarsened sample survives; earlier samples are not kept anywhere.
  return Object.freeze({ ...grant, sample: Object.freeze({ lat: coarsen(lat, grant.precision), lon: coarsen(lon, grant.precision), accuracy_m: accuracy, at }) });
}

function revokeLocationGrant(grant, { partyId, at }) {
  if (grant?.schema !== LOCATION_SCHEMA) throw new Error('Некоректний дозвіл');
  if (partyId !== grant.grantor_id) throw new Error('Відкликати може лише сторона, що дала дозвіл');
  if (!validInstant(at)) throw new Error('Некоректний час');
  return Object.freeze({ ...grant, status: 'revoked', closed_at: at, sample: null });
}

// Meeting cancelled/declined/over → the grant closes and the last position is dropped.
function closeLocationGrantForMeeting(grant, meeting, at) {
  if (grant?.schema !== LOCATION_SCHEMA || grant.status !== 'active') return grant;
  if (!validInstant(at)) throw new Error('Некоректний час');
  if (meeting?.id === grant.meeting_id && meeting.status === 'accepted' && at < grant.closes_at) return grant;
  return Object.freeze({ ...grant, status: 'closed', closed_at: at, sample: null });
}

function viewLocation(grant, { viewerId, now }) {
  if (grant?.schema !== LOCATION_SCHEMA || !validInstant(now)) return { visible: false, reason: 'INVALID' };
  const own = viewerId === grant.grantor_id;
  if (!own && viewerId !== grant.recipient_id) return { visible: false, reason: 'NOT_RECIPIENT' };
  if (grant.status === 'revoked') return { visible: false, reason: 'REVOKED', own };
  if (grant.status === 'closed') return { visible: false, reason: 'MEETING_CLOSED', own };
  if (now >= grant.closes_at) return { visible: false, reason: 'EXPIRED', own };
  if (now < grant.opens_at) return { visible: false, reason: 'NOT_YET_OPEN', own, opens_at: grant.opens_at };
  if (!grant.sample) return { visible: false, reason: 'NO_SAMPLE', own };
  const ageSeconds = Math.max(0, Math.round((Date.parse(now) - Date.parse(grant.sample.at)) / 1000));
  const radius = Math.max(grant.radius_m, grant.sample.accuracy_m ?? 0);
  return {
    visible: true, own, lat: grant.sample.lat, lon: grant.sample.lon, radius_m: radius, age_seconds: ageSeconds,
    stale: ageSeconds > STALE_AFTER_SECONDS,
    accuracy_label: grant.sample.accuracy_m === null ? 'точність пристрою невідома' : 'точність ~' + radius + ' м',
  };
}

// Static navigation needs no GPS and no SDK: an external Google Maps search link for the agreed place,
// opened only by the person's own click.
function staticNavigationUrl(place) {
  const destination = String(place ?? '').trim();
  if (!destination || isOnline(destination)) return null;
  return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(destination);
}

// Device location stays with Google Maps; Synera supplies only the agreed destination.
function meetingDirectionsUrl(place) {
  const search = staticNavigationUrl(place);
  if (!search) return null;
  const url = new URL('https://www.google.com/maps/dir/');
  url.search = new URLSearchParams({ api: '1', destination: new URL(search).searchParams.get('query'), travelmode: 'walking', dir_action: 'navigate' }).toString();
  return url.href;
}



const uuid = value => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
const reply = (body, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' } });
const invalid = () => reply({ error: 'location_invalid', status: 400 }, 400);
const key = grant => 'synera:location:v1:' + grant.id;
function locationReady(env) {
  return env.SYNERA_PILOT_READY === 'true' && env.SYNERA_LOCATION_READY === 'true' &&
    ['get', 'put', 'delete'].every(method => typeof env.SYNERA_LOCATION_EPHEMERAL?.[method] === 'function');
}
function normalized(grant) {
  if (!grant) return null;
  if (!uuid(grant.id) || grant.schema !== LOCATION_SCHEMA) throw new Error('Invalid location authority');
  return { ...grant, opens_at: new Date(grant.opens_at).toISOString(), closes_at: new Date(grant.closes_at).toISOString(), sample: null };
}

// Postgres owns identity, consent and access. KV holds only the latest coarsened
// sample, with absolute deletion at the grant's end. Never authorize from KV.
async function handleMeetingLocation(request, env, session, rpc) {
  if (!locationReady(env)) return reply({ error: 'location_unavailable', status: 503 }, 503);
  const url = new URL(request.url), match = url.pathname.match(/^\/api\/neon\/location\/([^/]+)\/(grant|sample|view|revoke)$/);
  if (request.method !== 'POST' || url.search || !match || !uuid(match[1])) return reply({ error: 'not_found', status: 404 }, 404);
  const [, meetingId, action] = match;
  const raw = await request.text();
  if (new TextEncoder().encode(raw).length > 1024) return invalid();
  let body;
  try { body = JSON.parse(raw); } catch { return invalid(); }
  const fields = { grant: ['precision', 'leadMinutes', 'consent', 'intentId'], sample: ['lat', 'lon', 'accuracyM'], view: [], revoke: [] }[action];
  if (!body || Array.isArray(body) || typeof body !== 'object' || Object.keys(body).some(name => !fields.includes(name))) return invalid();
  const args = { p_meeting_id: meetingId }, kv = env.SYNERA_LOCATION_EPHEMERAL;
  if (action === 'grant') {
    if (!uuid(body.intentId) || body.consent !== true || !['approximate', 'exact'].includes(body.precision) || ![15, 30].includes(body.leadMinutes)) return invalid();
    const previous = await rpc('synera_location_access', args);
    const grant = normalized(await rpc('synera_location_grant', { ...args, p_precision: body.precision, p_lead_minutes: body.leadMinutes, p_consent: true, p_intent_id: body.intentId }));
    if (previous.own && previous.own.id !== grant.id) await kv.delete(key(previous.own));
    return reply({ grant });
  }
  if (action === 'revoke') {
    const grant = normalized(await rpc('synera_location_revoke', args));
    // The database revocation already stops disclosure even if KV is unavailable.
    if (grant) await kv.delete(key(grant));
    return reply({ grant });
  }
  if (action === 'sample' && (![body.lat, body.lon].every(Number.isFinite) || Math.abs(body.lat)>90 || Math.abs(body.lon)>180 ||
    (body.accuracyM!==undefined && (!Number.isFinite(body.accuracyM)||body.accuracyM<0||body.accuracyM>100000)))) return invalid();
  const access = action === 'sample' ? await rpc('synera_location_sample', args).then(data => ({ eligible: true, own: data.grant, peer: null, server_now: data.server_now })) : await rpc('synera_location_access', args);
  const at = new Date(access.server_now).toISOString();
  const own = access.eligible ? normalized(access.own) : null, peer = access.eligible ? normalized(access.peer) : null;
  if (action === 'sample') {
    if (!own || own.grantor_id !== session.user.id || own.status !== 'active') return reply({ error: 'location_forbidden', status: 403 }, 403);
    const expiration = Math.floor(Date.parse(own.closes_at) / 1000);
    // KV requires at least 60 seconds. Never prolong permission to satisfy TTL.
    if (at < own.opens_at || expiration - Math.ceil(Math.max(Date.parse(at), Date.now()) / 1000) < 60) return reply({ error: 'location_window_closed', status: 409 }, 409);
    const updated = recordLocationSample(own, { partyId: session.user.id, ...body, at });
    await kv.put(key(own), JSON.stringify({ ...updated.sample, seq: own.sample_seq }), { expiration });
    return reply({ sample: updated.sample, server_now: at });
  }
  async function withSample(grant) {
    if (!grant || grant.status !== 'active' || at < grant.opens_at || at >= grant.closes_at) return grant;
    const sample = await kv.get(key(grant), { type: 'json' });
    if (!sample || sample.seq !== grant.sample_seq || !Number.isFinite(Date.parse(sample.at)) || sample.at < grant.opens_at || sample.at > at || sample.at >= grant.closes_at) return grant;
    return recordLocationSample(grant, { partyId: grant.grantor_id, lat: sample.lat, lon: sample.lon, accuracyM: sample.accuracy_m, at: sample.at });
  }
  const ownWithSample = await withSample(own), peerWithSample = await withSample(peer);
  // Recheck after the KV read: an in-flight view cannot retain authority across
  // a concurrent revocation or return an older admitted sequence.
  const current = await rpc('synera_location_access', args);
  const stillCurrent = (value, latest) => value && latest && value.id === latest.id && value.sample_seq === latest.sample_seq ? value : null;
  return reply({ eligible: current.eligible === true, own: current.eligible ? stillCurrent(ownWithSample, current.own) : null,
    peer: current.eligible ? stillCurrent(peerWithSample, current.peer) : null, meeting: current.meeting ?? null, server_now: current.server_now });
}

return {handleMeetingLocation,locationReady};
})();

const {handleGroupRoom,groupRoomsReady}=(()=>{
// Neon/Postgres owns identity, membership, turn revision and the clock.
// The gateway admits only this explicit RPC contract; it stores no transcripts.
const uuid=value=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
const reply=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});
function groupRoomsReady(env){return env.SYNERA_PILOT_READY==='true'&&env.SYNERA_GROUP_ROOMS_READY==='true';}
async function bodyOf(request){
  if(!/^application\/json(?:;|$)/i.test(request.headers.get('content-type')||''))return null;
  if(Number(request.headers.get('content-length'))>12288||!request.body)return null;
  const reader=request.body.getReader();let size=0,parts=[];
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>12288){await reader.cancel();return null;}parts.push(value);}
  const bytes=new Uint8Array(size);let at=0;for(const part of parts){bytes.set(part,at);at+=part.length;}
  try{const body=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));return body&&typeof body==='object'&&!Array.isArray(body)?body:null;}catch{return null;}
}
async function handleGroupRoom(request,env,session,rpc){
  if(!groupRoomsReady(env))return reply({error:'rooms_unavailable',status:503},503);
  if(!session?.user?.id)return reply({error:'rooms_unauthorized',status:401},401);
  const url=new URL(request.url),match=url.pathname.match(/^\/api\/neon\/rooms\/(?:(list|create)|([^/]+)\/(get|accept|leave|start|message|advance|close))$/);
  if(request.method!=='POST'||url.search||!match||(match[2]&&!uuid(match[2])))return reply({error:'not_found',status:404},404);
  const action=match[1]||match[3],body=await bodyOf(request),fields={list:[],create:['title','goal','invitee_ids'],get:[],accept:[],leave:[],start:['expected_revision'],message:['expected_revision','message_id','body'],advance:['expected_revision'],close:['expected_revision']}[action];
  const invalid=()=>reply({error:'rooms_invalid',status:400},400);
  if(!body||Object.keys(body).some(key=>!fields.includes(key)))return invalid();
  const args=match[2]?{p_room_id:match[2]}:{};
  if(action==='create'){
    if(typeof body.title!=='string'||body.title.trim().length<1||body.title.length>120||typeof body.goal!=='string'||body.goal.trim().length<1||body.goal.length>500||!Array.isArray(body.invitee_ids)||![1,2].includes(body.invitee_ids.length)||!body.invitee_ids.every(uuid)||new Set(body.invitee_ids).size!==body.invitee_ids.length||body.invitee_ids.includes(session.user.id))return invalid();
    Object.assign(args,{p_title:body.title.trim(),p_goal:body.goal.trim(),p_invitee_ids:body.invitee_ids});
  }
  if(fields.includes('expected_revision')){
    if(!Number.isSafeInteger(body.expected_revision)||body.expected_revision<1||body.expected_revision>2147483647)return invalid();
    args.p_expected_revision=body.expected_revision;
  }
  if(action==='message'){
    if(!uuid(body.message_id)||typeof body.body!=='string'||!body.body.trim()||body.body.length>2000)return invalid();
    Object.assign(args,{p_message_id:body.message_id,p_body:body.body.trim()});
  }
  return reply(await rpc('synera_room_'+action,args));
}

return {handleGroupRoom,groupRoomsReady};
})();

const {outcomeReady,outcomeRPCArgs}=(()=>{
// Narrow input contract for the existing Neon gateway. Identity and outcome
// transitions belong to the authenticated SQL RPC, never to browser fields.
function outcomeReady(env) {
  return env.SYNERA_PILOT_READY === 'true' && env.SYNERA_REAL_JOURNEY_READY === 'true' && env.SYNERA_CASE_OUTCOMES_READY === 'true';
}
const common=['action','version','termsHash'];
const actionFields={state:[],submit:['index','intentId','evidenceUri'],check:['index','intentId','scopeNotes'],accept:['index','intentId'],decline:['index','intentId','reason']};
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const text=value=>typeof value==='string' && Array.from(value.trim()).length>=1 && Array.from(value.trim()).length<=1000;
function outcomeRPCArgs(caseId,body) {
  if(typeof caseId!=='string'||!/^[A-Za-z0-9_:-]{1,64}$/.test(caseId)||!body||typeof body!=='object'||Array.isArray(body))throw new Error('Invalid outcome request');
  const extra=Object.hasOwn(actionFields,body.action)?actionFields[body.action]:null;
  if(!extra||Object.keys(body).some(key=>![...common,...extra].includes(key))||!Number.isSafeInteger(body.version)||body.version<1||body.version>999999999||
    typeof body.termsHash!=='string'||!/^[a-f0-9]{64}$/.test(body.termsHash))throw new Error('Invalid reviewed outcome');
  if(body.action!=='state'&&(!Number.isInteger(body.index)||body.index<0||body.index>9999||typeof body.intentId!=='string'||!uuid.test(body.intentId)))throw new Error('Invalid outcome intent');
  if(body.action==='submit'&&!text(body.evidenceUri))throw new Error('Evidence URI required');
  if(body.action==='check'&&!text(body.scopeNotes))throw new Error('Scope notes required');
  if(body.action==='decline'&&!['not_delivered','outside_agreed_scope','below_acceptance_criteria','other'].includes(body.reason))throw new Error('Neutral reason required');
  return {p_case_id:caseId,p_payload:structuredClone(body)};
}

return {outcomeReady,outcomeRPCArgs};
})();

const {meetingAddressReady,meetingAddressRPCArgs}=(()=>{
// Input-only adapter. SQL owns identity, revisions and bilateral decisions.
function meetingAddressReady(env) {
  return env.SYNERA_PILOT_READY === 'true' && env.SYNERA_REAL_JOURNEY_READY === 'true' && env.SYNERA_MEETING_ADDRESS_READY === 'true';
}
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const common=['action','version','termsHash'];
const fields={state:[],propose:['intentId','proposalId','address','consent'],accept:['intentId','proposalId','consent'],decline:['intentId','proposalId']};
function meetingAddressRPCArgs(meetingId,caseId,body) {
  if(typeof meetingId!=='string'||!uuid.test(meetingId)||typeof caseId!=='string'||!/^[A-Za-z0-9_:-]{1,64}$/.test(caseId)
    ||!body||typeof body!=='object'||Array.isArray(body))throw new Error('Invalid address request');
  const extra=Object.hasOwn(fields,body.action)?fields[body.action]:null;
  if(!extra||Object.keys(body).some(key=>![...common,...extra].includes(key))||!Number.isSafeInteger(body.version)||body.version<1||body.version>999999999
    ||typeof body.termsHash!=='string'||!/^[a-f0-9]{64}$/.test(body.termsHash)
    ||new TextEncoder().encode(JSON.stringify(body)).length>2048)throw new Error('Invalid reviewed address');
  if(body.action!=='state'){
    if(typeof body.intentId!=='string'||!uuid.test(body.intentId)||!Object.hasOwn(body,'proposalId')
      ||(body.proposalId!==null&&(typeof body.proposalId!=='string'||!uuid.test(body.proposalId))))throw new Error('Invalid address intent');
    if(body.action!=='propose'&&body.proposalId===null)throw new Error('Reviewed proposal required');
  }
  if(body.action==='propose'&&(typeof body.address!=='string'||Array.from(body.address.trim()).length<1||Array.from(body.address.trim()).length>200))throw new Error('Address required');
  if(['propose','accept'].includes(body.action)&&body.consent!==true)throw new Error('Explicit address choice required');
  return {p_meeting_id:meetingId,p_case_id:caseId,p_payload:structuredClone(body)};
}

return {meetingAddressReady,meetingAddressRPCArgs};
})();

const {profileErasureReady,profileErasureResult}=(()=>{
function profileErasureReady(env) {
  return env.SYNERA_PILOT_READY === 'true' && env.SYNERA_PROFILE_ERASURE_READY === 'true';
}
function profileErasureResult(value) {
  if (!value || value.status !== 'application_data_erased' || value.providerDeletion !== 'pending' ||
      value.retainedScope !== 'bilateral_records_and_safety_evidence' || typeof value.repeated !== 'boolean') {
    throw new Error('Unconfirmed profile erasure');
  }
  return { status:value.status, providerDeletion:value.providerDeletion, retainedScope:value.retainedScope, repeated:value.repeated };
}

return {profileErasureReady,profileErasureResult};
})();

const {caseMaterialBytes,CASE_MATERIAL_MAX_BYTES,CASE_REQUEST_MAX_BYTES}=(()=>{
// Matches octet_length(material::text) in the existing PostgreSQL JSONB constraint.
// Canonical material contains only strings, safe integers, booleans, null, arrays and objects.
const CASE_MATERIAL_MAX_BYTES = 16384;
// Room for the current row IDs, hash, timestamps and JSON envelope; only match_cases uses it.
const CASE_REQUEST_MAX_BYTES = CASE_MATERIAL_MAX_BYTES + 2048;
const CASE_MATERIAL_TOO_LARGE = 'Забагато тексту в умовах. Скороти опис; чернетка залишається у формі.';
function caseMaterialBytes(value) {
  const encode = item => {
    if (Array.isArray(item)) return '[' + item.map(encode).join(', ') + ']';
    if (item && typeof item === 'object') return '{' + Object.entries(item).map(([key, val]) => encode(key) + ': ' + encode(val)).join(', ') + '}';
    if (typeof item === 'string') {
      // PostgreSQL JSONB cannot represent NUL or unpaired UTF-16 surrogates.
      for (const char of item) { const point=char.codePointAt(0); if (point===0 || point>=0xd800 && point<=0xdfff) throw new Error('Некоректний символ у тексті умов.'); }
    } else if (item!==null && typeof item!=='boolean' && !Number.isSafeInteger(item)) throw new Error('Некоректне значення умов.');
    return JSON.stringify(item);
  };
  return new TextEncoder().encode(encode(value)).length;
}
function assertCaseMaterialBudget(value) {
  if (caseMaterialBytes(value) > CASE_MATERIAL_MAX_BYTES) throw new Error(CASE_MATERIAL_TOO_LARGE);
}

return {caseMaterialBytes,CASE_MATERIAL_MAX_BYTES,CASE_REQUEST_MAX_BYTES};
})();

const {normalizeOpenEmail,withOtpProtection,OtpProtectionError}=(()=>{
// Reuse the existing ephemeral KV namespace, with keys separate from location data.
// KV is eventually consistent: these are bounded best-effort limits across PoPs,
// serialized exactly within one isolate. Neon/edge limits remain required in production.
const WINDOW_MS = 15 * 60 * 1000;
const CODE_MS = 10 * 60 * 1000;
const MAX_ATTEMPTS = 5;
const locks = new WeakMap();
class OtpProtectionError extends Error {
  constructor(status, code, retryAfter = 0) { super(code); this.status = status; this.code = code; this.retryAfter = retryAfter; }
}
function normalizeOpenEmail(value) {
  if (typeof value !== 'string' || value.length > 254) throw new OtpProtectionError(400, 'service_unavailable');
  const email = value.trim().toLowerCase();
  if (!/^[^\s@,]+@[^\s@,]+\.[^\s@,]+$/.test(email)) throw new OtpProtectionError(400, 'service_unavailable');
  return email;
}
async function digest(value) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return Array.from(new Uint8Array(bytes), value => value.toString(16).padStart(2, '0')).join('');
}
async function locked(kv, keys, operation) {
  let map = locks.get(kv); if (!map) { map = new Map(); locks.set(kv, map); }
  async function acquire(index) {
    if (index === keys.length) return operation();
    const key = keys[index], previous = map.get(key) || Promise.resolve();
    let release; const pending = new Promise(resolve => { release = resolve; });
    map.set(key, pending);
    await previous;
    try { return await acquire(index + 1); }
    finally { if (map.get(key) === pending) map.delete(key); release(); }
  }
  return acquire(0);
}
async function record(kv, key) {
  const value = await kv.get(key, { type: 'json' });
  if (value === null) return null;
  if (!value || typeof value !== 'object' || !Number.isSafeInteger(value.expires) || !Number.isSafeInteger(value.count) || value.count < 0) throw new OtpProtectionError(503, 'service_unavailable');
  return value.expires > Date.now() ? value : null;
}
const save = (kv, key, value) => kv.put(key, JSON.stringify(value), { expirationTtl: Math.max(60, Math.ceil((value.expires - Date.now()) / 1000)) });
function limited(expires) { throw new OtpProtectionError(429, 'rate_limited', Math.max(1, Math.ceil((expires - Date.now()) / 1000))); }

async function withOtpProtection(env, email, request, action, operation, consent) {
  const kv = env.SYNERA_LOCATION_EPHEMERAL;
  if (!['get', 'put'].every(method => typeof kv?.[method] === 'function')) throw new OtpProtectionError(503, 'service_unavailable');
  const emailKey = 'synera:otp:v1:email:' + await digest(email);
  let ipKey;
  if (action === 'request') {
    // Only Cloudflare's overwritten connecting-IP header is trusted. Never X-Forwarded-For.
    const ip = request.headers.get('CF-Connecting-IP');
    if (!ip || ip.length > 45 || !/^[a-fA-F0-9:.]+$/.test(ip)) throw new OtpProtectionError(503, 'service_unavailable');
    ipKey = 'synera:otp:v1:ip:' + await digest(ip.toLowerCase());
  }
  return locked(kv, [emailKey, ...(ipKey ? [ipKey] : [])].sort(), async () => {
    const challengeKey = emailKey + ':code';
    if (action === 'request') {
      const emailCount = await record(kv, emailKey), ipCount = await record(kv, ipKey);
      for (const [value, cap] of [[emailCount, 3], [ipCount, 20]]) if (value && value.count >= cap) limited(value.expires);
      const increment = value => ({ expires: value?.expires ?? Date.now() + WINDOW_MS, count: (value?.count ?? 0) + 1 });
      // Reserve before provider traffic, including failed sends; never refund abuse attempts.
      await save(kv, ipKey, increment(ipCount)); await save(kv, emailKey, increment(emailCount));
      // A resend may reuse the provider's still-valid code. Keep failed guesses
      // until expiry; only a completed sign-in permits a new verification budget.
      const previous = await record(kv, challengeKey);
      await save(kv, challengeKey, { expires: previous && !previous.used ? previous.expires : Date.now() + CODE_MS,
        count: previous && !previous.used ? previous.count : 0, consent });
      return operation();
    }
    const challenge = await record(kv, challengeKey);
    if (!challenge || challenge.consent?.policy_version !== consent.policy_version || challenge.consent?.terms_accepted !== true || challenge.consent?.privacy_acknowledged !== true) throw new OtpProtectionError(400, 'otp_invalid');
    if (challenge.count >= MAX_ATTEMPTS) limited(challenge.expires);
    await save(kv, challengeKey, { ...challenge, count: challenge.count + 1 });
    const response = await operation();
    // A successful exchange consumes this issuance even if an upstream replay were possible.
    await save(kv, challengeKey, { ...challenge, count: MAX_ATTEMPTS, used: true });
    return response;
  });
}

return {normalizeOpenEmail,withOtpProtection,OtpProtectionError};
})();


// Deployment adapter, not an auth implementation: Neon verifies OTPs and owns sessions.
// All provider tokens stay here. No owner API key, SQL password, or service-role key is used.
const SESSION_COOKIE = '__Host-synera-session';
// Exact upstream name from neondatabase/neon-js packages/auth/src/server/constants.ts.
// The overview docs still show an older spelling; accepting it loses successful OTP sessions.
const NEON_COOKIE = '__Secure-neon-auth.session_token';
// match_cases and match_case_approvals are added by neon/case-state.migration.sql. The gateway only
// forwards; ownership and the one-approval-per-party rule are enforced by RLS on those tables.
const TABLES = new Set(['profiles', 'pilot_consents', 'meeting_requests', 'meeting_messages', 'profile_blocks', 'profile_reports',
  'match_cases', 'match_case_approvals']);
const METHODS = new Set(['GET', 'POST', 'PATCH', 'DELETE']);
const jsonHeaders = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' };
const answer = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), { status, headers: { ...jsonHeaders, ...headers } });
class GatewayError extends Error { constructor(status, code = 'service_unavailable', upstreamStatus) { super('Gateway request rejected'); this.status = status; this.code = code; this.upstreamStatus = upstreamStatus; } }

function originValue(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw new GatewayError(503);
  return url.origin;
}
export function neonEndpoints(env) {
  const auth = new URL(env.SYNERA_NEON_AUTH_URL), data = new URL(env.SYNERA_NEON_DATA_URL);
  for (const url of [auth, data]) {
    if (url.protocol !== 'https:' || url.username || url.password || url.port || url.search || url.hash || !/^[a-z0-9.-]+\.aws\.neon\.tech$/.test(url.hostname)) throw new GatewayError(503);
  }
  if (!auth.hostname.includes('.neonauth.') || !data.hostname.includes('.apirest.') || !/^\/[a-zA-Z0-9_-]+\/auth$/.test(auth.pathname) || !/^\/[a-zA-Z0-9_-]+\/rest\/v1$/.test(data.pathname)) throw new GatewayError(503);
  if (auth.hostname.replace('.neonauth.', '.') !== data.hostname.replace('.apirest.', '.') || auth.pathname.split('/')[1] !== data.pathname.split('/')[1]) throw new GatewayError(503);
  return { auth: auth.href, data: data.href, origin: originValue(env.SYNERA_SITE_URL) };
}
function participants(env) {
  if (env.SYNERA_OPEN_REGISTRATION === 'true') return { has(email) { try { normalizeOpenEmail(email); return true; } catch { return false; } } };
  const emails = String(env.SYNERA_PILOT_EMAILS || '').split(',').map(v => v.trim().toLowerCase()).filter(Boolean);
  if (!emails.length || emails.length > 10 || emails.some(v => !/^[^\s@,]+@[^\s@,]+\.[^\s@,]+$/.test(v))) throw new GatewayError(503);
  return new Set(emails);
}
function cookieValue(request) {
  const matches = (request.headers.get('cookie') || '').split(';').map(v => v.trim()).filter(v => v.startsWith(SESSION_COOKIE + '='));
  if (matches.length > 1) throw new GatewayError(401);
  const value = matches[0]?.slice(SESSION_COOKIE.length + 1) || '';
  if (value.length > 4096 || /[^\x21-\x3a\x3c-\x7e]/.test(value)) throw new GatewayError(401);
  return value;
}
function providerCookie(response) {
  const values = response.headers.getSetCookie();
  const found = values.map(v => v.split(';')[0]).filter(v => v.startsWith(NEON_COOKIE + '='));
  if (found.length !== 1) throw new GatewayError(503, 'session_cookie_unavailable');
  const value = found[0].slice(NEON_COOKIE.length + 1);
  if (!value || value.length > 4096 || /[^\x21-\x3a\x3c-\x7e]/.test(value)) throw new GatewayError(503, 'session_cookie_unavailable');
  return value;
}
function sessionCookie(value) { return `${SESSION_COOKIE}=${value}; Path=/; Secure; HttpOnly; SameSite=Lax${value ? '' : '; Max-Age=0'}`; }
function publicUser(data, allowed) {
  const user = data?.user;
  if (!user || typeof user.id !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(user.id) || typeof user.email !== 'string' || user.emailVerified !== true || !allowed.has(user.email.toLowerCase())) throw new GatewayError(401);
  return { id: user.id, email: user.email };
}
async function readJson(request, maxBytes = 4096) {
  if (!/^application\/json(?:;|$)/i.test(request.headers.get('content-type') || '')) throw new GatewayError(415);
  if (Number(request.headers.get('content-length')) > maxBytes) throw new GatewayError(413);
  if (!request.body) return {};
  const reader = request.body.getReader(); let size = 0, chunks = [];
  while (true) {
    const { value, done } = await reader.read(); if (done) break;
    size += value.length;
    if (size > maxBytes) { await reader.cancel(); throw new GatewayError(413); }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  try { const value = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(); return value; }
  catch { throw new GatewayError(400); }
}
function checkKeys(body, expected) { if (Object.keys(body).some(key => !expected.includes(key))) throw new GatewayError(400); }
function checkedEmail(body, allowed, env) {
  if (env.SYNERA_OPEN_REGISTRATION === 'true') return normalizeOpenEmail(body.email);
  if (typeof body.email !== 'string' || body.email.length > 254) throw new GatewayError(400);
  const email = body.email.trim().toLowerCase();
  if (!allowed.has(email)) throw new GatewayError(403);
  return email;
}
async function checkedFetch(fetchImpl, url, init, code = 'service_unavailable') {
  let response;
  try { response = await fetchImpl(url, { ...init, redirect: 'manual', signal: AbortSignal.timeout(12000), cache: 'no-store' }); }
  catch { throw new GatewayError(503, code); }
  if (!response.ok) throw new GatewayError([400, 401, 403, 409, 422, 429].includes(response.status) ? response.status : 503,
    code === 'otp_verification_unavailable' && [400, 401, 422].includes(response.status) ? 'otp_invalid' : code, response.status);
  return response;
}
async function authRequest(fetchImpl, endpoints, path, { method = 'GET', body, cookie = '' } = {}) {
  return checkedFetch(fetchImpl, endpoints.auth + path, { method, headers: { 'Content-Type': 'application/json', Origin: endpoints.origin,
    'X-Neon-Auth-Middleware': 'true', ...(cookie ? { Cookie: `${NEON_COOKIE}=${cookie}` } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) },
    path === '/sign-in/email-otp' ? 'otp_verification_unavailable' : path === '/email-otp/send-verification-otp' ? 'otp_delivery_unavailable' : 'session_unavailable');
}
async function getSession(fetchImpl, endpoints, cookie, allowed) {
  if (!cookie) return null;
  const response = await authRequest(fetchImpl, endpoints, '/get-session', { cookie });
  const data = await response.json();
  if (!data?.session) return null;
  const user = publicUser(data, allowed), jwt = response.headers.get('set-auth-jwt');
  // Shape validation only. The Neon Data API, not this proxy, verifies the signature.
  if (!jwt || !/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(jwt) || jwt.length > 16384) throw new GatewayError(503, 'session_token_unavailable');
  return { user, jwt };
}

export async function handleNeon(request, env, fetchImpl = fetch) {
  try {
    const url = new URL(request.url), endpoints = neonEndpoints(env);
    // OAuth returns by top-level navigation without the fetch-only client header.
    // Its dedicated challenge + verifier are checked by the OAuth adapter.
    if (url.origin === endpoints.origin && url.pathname === '/api/neon/oauth/google/callback' && request.method === 'GET') {
      const result = await handleGoogleOAuth(request, env, endpoints, participants(env), fetchImpl);
      if (result.status < 400) return result;
      const headers = new Headers({ Location: endpoints.origin + '/?signin=google-error', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
      for (const cookie of result.headers.getSetCookie()) headers.append('Set-Cookie', cookie);
      return new Response(null, { status: 303, headers });
    }
    if (url.origin !== endpoints.origin || request.headers.get('X-Synera-Client') !== '1' || request.headers.get('Sec-Fetch-Site') === 'cross-site') throw new GatewayError(403);
    const origin = request.headers.get('Origin');
    if ((request.method !== 'GET' && origin !== endpoints.origin) || (origin && origin !== endpoints.origin)) throw new GatewayError(403);
    if (!METHODS.has(request.method)) throw new GatewayError(405);
    const path = url.pathname.slice('/api/neon'.length), cookie = cookieValue(request);
    if (path === '/logout' && request.method === 'POST') {
      if (cookie) await authRequest(fetchImpl, endpoints, '/sign-out', { method: 'POST', body: {}, cookie });
      return answer({ signedOut: true }, 200, { 'Set-Cookie': sessionCookie('') });
    }
    if (env.SYNERA_PILOT_READY !== 'true') throw new GatewayError(503);
    const allowed = participants(env);
    if (path === '/health' && request.method === 'GET' && !url.search) {
      await authRequest(fetchImpl, endpoints, '/get-session');
      return answer({ authGateway: 'reachable', backend: 'neon', policyVersion: POLICY_VERSION });
    }
    if (path === '/oauth/google/start' && request.method === 'POST' && !url.search) {
      return await handleGoogleOAuth(request, env, endpoints, allowed, fetchImpl);
    }
    // Starting authentication is a consent-bearing, same-origin POST.
    if (path === '/oauth/google/start' && request.method === 'GET' && !url.search) {
      throw new GatewayError(404, 'not_found');
    }
    if (path === '/otp/request' && request.method === 'POST' && !url.search) {
      if (env.SYNERA_REGISTRATION_ENABLED !== 'true') throw new GatewayError(403);
      const body = await readJson(request); checkKeys(body, ['email', 'consent']);
      if (body.consent?.policy_version !== POLICY_VERSION) throw new GatewayError(400);
      try { consentRecord(body.consent); } catch { throw new GatewayError(400); }
      const email = checkedEmail(body, allowed, env);
      const send = async () => {
        try { await authRequest(fetchImpl, endpoints, '/email-otp/send-verification-otp', { method: 'POST', body: { email, type: 'sign-in' } }); }
        catch (error) {
          // Provider account-existence errors receive the same response as a sent code.
          if (env.SYNERA_OPEN_REGISTRATION !== 'true' || !(error instanceof GatewayError) || ![400, 401, 403, 404, 409, 422].includes(error.upstreamStatus ?? error.status)) throw error;
        }
      };
      if (env.SYNERA_OPEN_REGISTRATION === 'true') await withOtpProtection(env, email, request, 'request', send, consentRecord(body.consent));
      else await send();
      return answer({ sent: true });
    }
    if (path === '/otp/verify' && request.method === 'POST' && !url.search) {
      if (env.SYNERA_REGISTRATION_ENABLED !== 'true') throw new GatewayError(403);
      const body = await readJson(request); checkKeys(body, ['email', 'otp']); const email = checkedEmail(body, allowed, env);
      if (typeof body.otp !== 'string' || !/^\d{6}$/.test(body.otp)) throw new GatewayError(400);
      const verify = async () => {
        try {
          const response = await authRequest(fetchImpl, endpoints, '/sign-in/email-otp', { method: 'POST', body: { email, otp: body.otp } });
          const user = publicUser(await response.json(), allowed);
          if (user.email.toLowerCase() !== email) throw new GatewayError(401);
          return answer({ user }, 200, { 'Set-Cookie': sessionCookie(providerCookie(response)) });
        } catch (error) {
          if (env.SYNERA_OPEN_REGISTRATION === 'true' && error instanceof GatewayError && [400, 401, 403, 404, 409, 422].includes(error.upstreamStatus ?? error.status)) throw new GatewayError(400, 'otp_invalid');
          throw error;
        }
      };
      return env.SYNERA_OPEN_REGISTRATION === 'true'
        ? await withOtpProtection(env, email, request, 'verify', verify, { policy_version: POLICY_VERSION }) : await verify();
    }
    if (path === '/session' && request.method === 'GET' && !url.search) {
      const session = await getSession(fetchImpl, endpoints, cookie, allowed);
      // A read can finish after another tab signed in. Only explicit logout clears cookies.
      return answer({ user: session?.user || null });
    }
    if (path === '/profile-erasure') {
      if (!profileErasureReady(env)) throw new GatewayError(503, 'profile_erasure_not_ready');
      if (request.method !== 'POST' || url.search) throw new GatewayError(404, 'not_found');
      const body = await readJson(request); checkKeys(body, ['confirm', 'expectedSubject']);
      if (body.confirm !== 'ERASE_APPLICATION_DATA') throw new GatewayError(400, 'profile_erasure_confirmation_required');
      if (typeof body.expectedSubject !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(body.expectedSubject)) throw new GatewayError(400, 'profile_erasure_confirmation_required');
      const session = await getSession(fetchImpl, endpoints, cookie, allowed);
      if (!session) throw new GatewayError(401);
      // A precondition, never an RPC target: SQL still gets only the verified bearer.
      if (body.expectedSubject !== session.user.id) throw new GatewayError(409, 'profile_erasure_subject_mismatch');
      const response = await checkedFetch(fetchImpl, endpoints.data + '/rpc/synera_erase_profile_data', {
        method:'POST', headers:{'Content-Type':'application/json', Authorization:'Bearer ' + session.jwt}, body:'{}',
      }, 'profile_erasure_unavailable');
      const result = profileErasureResult(await response.json());
      // Erasure is already committed. A provider sign-out failure must not pretend it rolled back.
      let sessionRevoked = true;
      try { await authRequest(fetchImpl, endpoints, '/sign-out', {method:'POST',body:{},cookie}); }
      catch { sessionRevoked = false; }
      // No Set-Cookie: this response may arrive after this browser signed into B.
      // Revoke the captured A provider session only; its stale JWT is fenced by SQL.
      return answer({...result,sessionRevoked});
    }
    if (path.startsWith('/messages/')) {
      if (env.SYNERA_REAL_JOURNEY_READY !== 'true' || env.SYNERA_MESSAGE_INTENTS_READY !== 'true') throw new GatewayError(503, 'message_intents_not_ready');
      const route = path.match(/^\/messages\/([a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12})$/);
      if (!route || request.method !== 'POST' || url.search) throw new GatewayError(404, 'not_found');
      const body = await readJson(request); checkKeys(body, ['intentId', 'text']);
      if (typeof body.intentId !== 'string' || !/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(body.intentId) || typeof body.text !== 'string' || !body.text.trim() || body.text.length > 1000 || body.text !== body.text.trim()) throw new GatewayError(400, 'message_invalid');
      const session = await getSession(fetchImpl, endpoints, cookie, allowed);
      if (!session) throw new GatewayError(401);
      const response = await checkedFetch(fetchImpl, endpoints.data + '/rpc/synera_send_message', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.jwt },
        body: JSON.stringify({ p_meeting_id: route[1], p_intent_id: body.intentId, p_body: body.text }),
      }, 'message_unavailable');
      return new Response(response.body, { status: response.status, headers: jsonHeaders });
    }
    if (path.startsWith('/meeting-address/')) {
      if (!meetingAddressReady(env)) throw new GatewayError(503, 'meeting_address_unavailable');
      const route = path.match(/^\/meeting-address\/([a-f0-9-]{36})\/([A-Za-z0-9_:-]{1,64})$/);
      if (!route || request.method !== 'POST' || url.search) throw new GatewayError(404, 'not_found');
      const body = await readJson(request); let args;
      try { args = meetingAddressRPCArgs(route[1], route[2], body); } catch { throw new GatewayError(400, 'meeting_address_invalid'); }
      const session = await getSession(fetchImpl, endpoints, cookie, allowed);
      if (!session) throw new GatewayError(401);
      const response = await checkedFetch(fetchImpl, endpoints.data + '/rpc/synera_meeting_address', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.jwt }, body: JSON.stringify(args),
      }, 'meeting_address_unavailable');
      return answer(await response.json());
    }
    if (path.startsWith('/outcomes/')) {
      if (!outcomeReady(env)) throw new GatewayError(503, 'outcomes_unavailable');
      const route = path.match(/^\/outcomes\/([A-Za-z0-9_:-]{1,64})$/);
      if (!route || request.method !== 'POST' || url.search) throw new GatewayError(404, 'not_found');
      const body = await readJson(request); let args;
      try { args = outcomeRPCArgs(route[1], body); } catch { throw new GatewayError(400, 'outcome_invalid'); }
      const session = await getSession(fetchImpl, endpoints, cookie, allowed);
      if (!session) throw new GatewayError(401);
      const response = await checkedFetch(fetchImpl, endpoints.data + '/rpc/synera_case_outcome', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.jwt }, body: JSON.stringify(args),
      }, 'outcomes_unavailable');
      return answer(await response.json());
    }
    if (path.startsWith('/rooms/')) {
      if (!groupRoomsReady(env)) throw new GatewayError(503, 'rooms_unavailable');
      const session = await getSession(fetchImpl, endpoints, cookie, allowed);
      if (!session) throw new GatewayError(401);
      const rpc = async (name, body) => (await checkedFetch(fetchImpl, endpoints.data + '/rpc/' + name, {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.jwt }, body: JSON.stringify(body),
      }, 'rooms_unavailable')).json();
      return await handleGroupRoom(request, env, session, rpc);
    }
    if (path.startsWith('/location/')) {
      const session = await getSession(fetchImpl, endpoints, cookie, allowed);
      if (!session) throw new GatewayError(401);
      const rpc = async (name, body) => (await checkedFetch(fetchImpl, endpoints.data + '/rpc/' + name, {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.jwt }, body: JSON.stringify(body),
      }, 'location_unavailable')).json();
      return await handleMeetingLocation(request, env, session, rpc);
    }
    const match = path.match(/^\/data\/([a-z_]+)$/);
    if (!match || !TABLES.has(match[1]) || url.search.length > 4096) throw new GatewayError(404);
    if (['match_cases', 'match_case_approvals'].includes(match[1]) && env.SYNERA_REAL_JOURNEY_READY !== 'true') throw new GatewayError(503, 'real_journey_not_ready');
    if (match[1] === 'match_cases' && request.method === 'PATCH') {
      const filters = [['case_id', /^eq\.[A-Za-z0-9_:-]{1,64}$/], ['version', /^eq\.[1-9][0-9]{0,8}$/], ['terms_hash', /^eq\.[a-f0-9]{64}$/], ['status', /^eq\.open$/]];
      if (filters.some(([key, pattern]) => url.searchParams.getAll(key).length !== 1 || !pattern.test(url.searchParams.get(key)))) throw new GatewayError(400, 'reviewed_case_required');
    }
    const session = await getSession(fetchImpl, endpoints, cookie, allowed);
    if (!session) throw new GatewayError(401);
    const body = ['POST', 'PATCH'].includes(request.method) ? await readJson(request, match[1] === 'match_cases' ? CASE_REQUEST_MAX_BYTES : 4096) : undefined;
    if (match[1] === 'match_cases' && body && Object.hasOwn(body, 'material')) {
      let size;
      try { size = caseMaterialBytes(body.material); } catch { throw new GatewayError(400, 'case_material_invalid'); }
      if (size > CASE_MATERIAL_MAX_BYTES) throw new GatewayError(413, 'case_material_too_large');
    }
    const prefer = request.headers.get('Prefer');
    if (prefer && !/^(return=(minimal|representation)|resolution=(merge|ignore)-duplicates)(,(return=(minimal|representation)|resolution=(merge|ignore)-duplicates))*$/.test(prefer)) throw new GatewayError(400);
    const response = await checkedFetch(fetchImpl, endpoints.data + '/' + match[1] + url.search, { method: request.method,
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + session.jwt, ...(prefer ? { Prefer: prefer } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }) }, 'data_unavailable');
    // RLS and column grants enforce ownership even if somebody bypasses the browser UI.
    return new Response(response.body, { status: response.status, headers: jsonHeaders });
  } catch (error) {
    const known = error instanceof GatewayError || error instanceof OtpProtectionError;
    const status = known ? error.status : 503;
    const requestPath = new URL(request.url).pathname;
    const clear = requestPath === '/api/neon/logout';
    return answer({ error: known ? error.code : 'service_unavailable', status }, status,
      { ...(clear ? { 'Set-Cookie': sessionCookie('') } : {}), ...(error.retryAfter ? { 'Retry-After': String(error.retryAfter) } : {}) });
  }
}

export function createNeonWorker(publicAssets) {
  // Pages redirects .html URLs to extensionless paths. Admit only aliases of
  // already-public HTML files, otherwise /legal.html redirects into our 404.
  const allowedAssets = new Set(['/', ...publicAssets.flatMap(name => name.endsWith('.html') ? ['/' + name, '/' + name.slice(0, -5)] : ['/' + name])]);
  return { async fetch(request, env) {
    const url = new URL(request.url);
    let response;
    if (url.pathname.startsWith('/api/neon/')) response = await handleNeon(request, env);
    else if (url.pathname === '/config.json' && request.method === 'GET') {
      const ready = env.SYNERA_PILOT_READY === 'true';
      const googleOAuthEnabled = ready && env.SYNERA_REGISTRATION_ENABLED === 'true' && env.SYNERA_GOOGLE_OAUTH_READY === 'true';
      // A misconfigured provider URL must close the optional sign-in, not crash the public configuration.
      let googleOAuthInitUrl; try { googleOAuthInitUrl = googleOAuthEnabled ? neonEndpoints(env).auth + '/sign-in/social/init' : undefined; } catch { googleOAuthInitUrl = undefined; }
      response = answer({ backend: 'neon', supabaseUrl: '', publishableKey: '', pilotSafetyEnabled: ready, realPilotEnabled: ready,
        // This new gate is set only after the documented challenge bridge is verified live.
        googleOAuthEnabled: googleOAuthEnabled && Boolean(googleOAuthInitUrl), googleOAuthInitUrl, liveLocationEnabled: locationReady(env), groupRoomsEnabled: groupRoomsReady(env),
        // Closed until case SQL/RLS and two distinct provider sessions pass acceptance.
        realJourneyEnabled: ready && env.SYNERA_REAL_JOURNEY_READY === 'true',
        messageIntentsEnabled: ready && env.SYNERA_REAL_JOURNEY_READY === 'true' && env.SYNERA_MESSAGE_INTENTS_READY === 'true',
        caseOutcomesEnabled: outcomeReady(env),
        meetingAddressEnabled: meetingAddressReady(env),
        profileErasureEnabled: profileErasureReady(env),
        registrationEnabled: ready && env.SYNERA_REGISTRATION_ENABLED === 'true', publicSiteUrl: url.origin });
    } else if (allowedAssets.has(url.pathname) && ['GET', 'HEAD'].includes(request.method)) response = await env.ASSETS.fetch(request);
    else response = answer({ error: 'not_found' }, 404);
    const headers = new Headers(response.headers);
    headers.set('Cache-Control', 'no-store'); headers.set('Strict-Transport-Security', 'max-age=31536000'); headers.set('X-Content-Type-Options', 'nosniff'); headers.set('Referrer-Policy', 'no-referrer');
    headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=' + (locationReady(env) ? '(self)' : '()'));
    headers.set('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data: https://tile.openstreetmap.org; worker-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    return new Response(response.body, { status: response.status, headers });
  } };
}

export default createNeonWorker(["adaptive.mjs","adaptive-ui.mjs","adaptive-config.mjs","adaptive-i18n-table.mjs","adaptive.css","site-shell.css","site-shell.mjs","premium-match.webp","premium-calendar.webp","premium-terms.webp","premium-signature.webp","index.html","app.mjs","style-switcher.mjs","atelier.css","atelier.mjs","online-store.mjs","profile-portability.mjs","profile-brief.mjs","calendar.mjs","style.css","matching.mjs","onboarding-tour.mjs","install-hint.mjs","location-session.mjs","demo-journey.mjs","simulation.html","simulation.css","simulation-ui.mjs","simulation-session.mjs","simulation-personas.mjs","simulation.webmanifest","simulation-sw.mjs","summit.html","summit.css","summit.mjs","get.html","product-access.mjs","triangle.html","triangle.css","triangle.mjs","triangle-room.mjs","explore-planner.mjs","studio.html","studio.css","studio.mjs","studio-journey.html","journey.css","journey-ui.mjs","journey-core.mjs","journey-ai-client.mjs","journey-handoff.mjs","real-journey.html","real-journey.css","real-journey.mjs","real-journey-client.mjs","real-journey-i18n.mjs","index-language.mjs","index-i18n.mjs","index-i18n-table.mjs","legal-language.mjs","legal-i18n.mjs","result-card.mjs","action-scoper.mjs","case-material-budget.mjs","outcome-archive.html","outcome-archive.mjs","outcome-archive-ui.mjs","portrait-mara.webp","portrait-noor.webp","portrait-leo.webp","icon-map-pin.svg","icon-message-circle.svg","icon-handshake.svg","icon-archive.svg","icon-code-xml.svg","icon-pen-tool.svg","icon-megaphone.svg","asset-licenses.txt","rooms.html","rooms.css","rooms.mjs","room-api.mjs","studio-install.mjs","studio-sw.mjs","studio.webmanifest","session-value.mjs","declared-fit.mjs","group-logistics.mjs","archive-codec.mjs","profile-store.mjs","neon-store.mjs","chatgpt-transfer.mjs","map.mjs","pilot-policy.mjs","profile-package.mjs","business-case.mjs","profile-import.mjs","i18n.mjs","proof-state.mjs","need-decay.mjs","meeting-card.mjs","live-location.mjs","meeting-location.mjs","cycle-exchange.mjs","b-matching.mjs","field-audience.mjs","swiss-compliance.mjs","funnel-analytics.mjs","manifest.webmanifest","pwa.mjs","sw.mjs","legal.html","catalogue.html","icon-192.png","icon-512.png","apple-touch-icon.png","tokens.css","montserrat-400.woff2","montserrat-500.woff2","cascade.mjs","iceberg-client.mjs"]);
